public class RandomBoy
{
	String direction;
	int pY, pX;
	public RandomBoy()
	{
		direction = "up";
	}
	public String retRandomDir()
	{
		if(Math.random() < .5)
			return "left";
		else
			return "right";
	}
	public String retRandomDirY()
	{
		if(Math.random() < .5)
			return "up";
		else
			return "down";
	}
	public void directionChange(char[][] b, int abY, int abX)
	{
		pY = abY;
		pX = abX;
		if(direction.equals("up"))
		{
			if(b[pY-1][pX] == '0')
			{
				if(b[pY][pX+1] == '0')
					direction = "left";
				else if(b[pY][pX-1] == '0')
					direction = "right";
				else
					direction = retRandomDir();
			}
		}
		if(direction.equals("left"))
		{
			if(b[pY][pX-1] == '0')
			{
				if(b[pY-1][pX] == '0')
					direction = "down";
				else if(b[pY+1][pX] == '0')
					direction = "up";
				else
					direction = retRandomDirY();
			}
		}
		if(direction.equals("right"))
		{
			if(b[pY][pX+1] == '0')
			{
				if(b[pY+1][pX] == '0')
					direction = "up";
				else if(b[pY-1][pX] == '0')
					direction = "down";
				else
					direction = retRandomDirY();
			}
		}
		if(direction.equals("down"))
		{
			if(b[pY+1][pX] == '0')
				{
					if(b[pY][pX-1] == '0')
						direction = "right";
					else if(b[pY][pX+1] == '0')
						direction = "left";
					else
						direction = retRandomDir();
				}
		}
	}
	public void calcCoords(char[][] b, int lbY, int lbX)
	{
		directionChange(b, lbY, lbX);
		if(direction.equals("up"))
		{
			pY--;
		}
		else if(direction.equals("left"))
		{
			pX--;
		}
		else if(direction.equals("right"))
		{
			pX++;
		}
		else
		{
			pY++;
		}
	}
	public int retPX()
	{
		return pX;
	}
	public int retPY()
	{
		return pY;
	}
	public String retDir()
	{
		return direction;
	}
}