public class PacManAI
{
	char dir;
	char[][] board = new char[7][7];
	int pX;
	int pY;
	int onlyTwice;
	char[][] sBoard = new char[7][7];
	public PacManAI()
	{
		for(int i = 0; i < 7; i++)
		{
			for(int j = 0; j< 7; j++)
			{
				if(i > 1 && j < 5 && j > 1 && i < 5)
					board[i][j] = '0';
				else if(i == 0 || j == 0 || i == 6 || j == 6)
					board[i][j] = '0';
				else
					board[i][j] = '2';
			}
		}
		board[2][3] = '0';
		board[3][4] = '0';
		board[3][2] = '0';
		board[4][3] = '0';
		//board[1][5] = '0';
		board[5][5] = 'p';
		board[3][3] = '0';
		pX = 1;
		pY = 1;
		onlyTwice = 0;
		for(int i = 0; i < 7; i++)
		{
			for(int j = 0; j< 7; j++)
			{
				System.out.print(board[i][j] + "\t");
			}
			System.out.println();
		}
		//calcMove(5, 5);
	}
	public PacManAI(char[][] boardR, int y, int x, int SY, int SX)
	{
		onlyTwice = 0;
		System.out.println(y + "  " + x);
		for(int i = 0; i < 7; i++)
		{
			for(int j = 0; j< 7; j++)
			{
				if(i > 1 && j < 5 && j > 1 && i < 5)
					board[i][j] = '0';
				else if(i == 0 || j == 0 || i == 6 || j == 6)
					board[i][j] = '0';
				else
					board[i][j] = '2';
			}
		}
		board[y][x] = 'p';
		board[SY][SX] = 1;
		pX = SY;
		pY = SX;
		for(int i = 0; i < 7; i++)
		{
			for(int j = 0; j< 7; j++)
			{
				System.out.print(board[i][j] + "\t");
			}
			System.out.println();
		}
		System.out.println("Player at " + y + "," + x + " and ghost at " + SY + "," + SX);
		calcMove(y,x);
	}
	public Boolean valid(int row, int column)
	{
		if(board[column][row] != '0')
			return true;
		else
			System.out.println(board[column][row] + " Is not vaild");
		return false;
	}
	public Boolean calcMove(int row, int column)
	{;
		boolean done = false;
		if(valid(row, column))
		{
			board[column][row] = '3';
			if(column == pX && row == pY)
				done = true;
			else
			{
			done = calcMove(row, column-1);
			System.out.println("trying left");
				if(!done)
				{
					done = calcMove(row, column+1);
					System.out.println("trying right");
				}
				if(!done)
				{
					done = calcMove(row-1, column);
					System.out.println("trying up");
				}
				if(!done)
				{
					done = calcMove(row+1, column);
					System.out.println("trying down");
				}
			}
			if(done)
			{
				System.out.println("solu");
				//board[column][row] = 1;
				if(onlyTwice == 0)
				{
					System.out.println("only Problem");
					onlyTwice++;
				}
				else
				{
					board[row][column] = 1;
					for(int i = 0; i < 7; i++)
					{
						for(int j = 0; j < 7; j++)
						{

							if(board[i][j] == '3')
								board[i][j] = '2';
							System.out.print(board[i][j] + "\t");
						}
						System.out.println();
					}
					System.out.println("AI");
					return false;
				}
					return done;
				}
		}
		return done;
	}
	public char[][] retBoard()
	{
		return board;
	}
	public int retPX()
	{
		return pX;
	}
	public int retPY()
	{
		return pY;
	}
}