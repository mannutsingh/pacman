import java.util.Scanner;
public class PacManRunner
{
	public static void main(String[] args)
	{
		boolean victory = false;
		int cycles = 0;
		char dir;
		int pX = 9, pY = 15;
		int lbX = 9, lbY = 8;
		int rbX = 9, rbY = 9;
		int abX = 9, abY = 9;
		int sbX = 9, sbY = 9;
		int plbX = 0, plbY = 0, prbX = 0, prbY = 0,pabX = 0, pabY = 0, psbX = 0, psbY = 0;
		char storeLB = '?';
		char storeRB = '?';
		char storeAB = '?';
		char storeSB = '?';
		char[][] board = new char[][]
		{
	      {'0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0'},
	      {'0', '2', '2', '2', '2', '2', '2', '2', '2', '0', '2', '2', '2', '2', '2', '2', '2', '2', '0'},
	      {'0', '2', '0', '0', '2', '0', '0', '0', '2', '0', '2', '0', '0', '0', '2', '0', '0', '2', '0'},
	      {'0', '2', '2', '2', '2', '2', '2', '2', '2', '2', '2', '2', '2', '2', '2', '2', '2', '2', '0'},
	      {'0', '2', '0', '0', '2', '0', '2', '0', '0', '0', '0', '0', '2', '0', '2', '0', '0', '2', '0'},
	      {'0', '2', '2', '2', '2', '0', '2', '2', '2', '0', '2', '2', '2', '0', '2', '2', '2', '2', '0'},
	      {'0', '0', '0', '0', '2', '0', '0', '0', '2', '0', '2', '0', '0', '0', '2', '0', '0', '0', '0'},
	      {'0', '0', '0', '0', '2', '0', '2', '2', '2', '2', '2', '2', '2', '0', '2', '0', '0', '0', '0'},
	      {'0', '0', '0', '0', '2', '0', '2', '0', '0', '3', '0', '0', '2', '0', '2', '0', '0', '0', '0'},
	      {'2', '2', '2', '2', '2', '2', '2', '0', '3', '3', '3', '0', '2', '2', '2', '2', '2', '2', '2'},
	      {'0', '0', '0', '0', '2', '0', '2', '0', '0', '0', '0', '0', '2', '0', '2', '0', '0', '0', '0'},
	      {'0', '0', '0', '0', '2', '0', '2', '2', '2', '2', '2', '2', '2', '0', '2', '0', '0', '0', '0'},//directly below ghost storage
	      {'0', '0', '0', '0', '2', '0', '2', '0', '0', '0', '0', '0', '2', '0', '2', '0', '0', '0', '0'},
	      {'0', '2', '2', '2', '2', '2', '2', '2', '2', '0', '2', '2', '2', '2', '2', '2', '2', '2', '0'},
	      {'0', '2', '0', '0', '2', '0', '0', '0', '2', '0', '2', '0', '0', '0', '2', '0', '0', '2', '0'},
	      {'0', '2', '2', '0', '2', '2', '2', '2', '2', 'p', '2', '2', '2', '2', '2', '0', '2', '2', '0'},
	      {'0', '0', '2', '0', '2', '0', '2', '0', '0', '0', '0', '0', '2', '0', '2', '0', '2', '0', '0'},//directly below player
	      {'0', '2', '2', '2', '2', '0', '2', '2', '2', '0', '2', '2', '2', '0', '2', '2', '2', '2', '0'},
	      {'0', '2', '0', '0', '0', '0', '0', '0', '2', '0', '2', '0', '0', '0', '0', '0', '0', '2', '0'},
	      {'0', '2', '2', '2', '2', '2', '2', '2', '2', '0', '2', '2', '2', '2', '2', '2', '2', '2', '0'},
	      {'0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0'}
		};
		Scanner sc = new Scanner(System.in);
		LeftyBoy lb = new LeftyBoy();
		RightyBoy rb = new RightyBoy();
		RandomBoy ab = new RandomBoy();
		SearchBoy sb = new SearchBoy();
		PacMan p;
		while(true)
		{
			for(int i = 0; i < board.length; i++)
			{
				for(int j = 0; j < board[0].length; j++)
				{
					System.out.print(board[i][j]+ "  ");
				}
				System.out.println();
			}
			dir = sc.nextLine().charAt(0);
			p = new PacMan(dir, board, pX, pY);
			pX = p.retPX();
			pY = p.retPY();
			board = p.retBoard();
			plbX = lbX;
			plbY = lbY;
			lb.calcCoords(board, lbY, lbX);
			System.out.println("LB moving " + lb.retDir());
			lbY = lb.retPY();
			lbX = lb.retPX();
			if(cycles > 0)
				board[plbY][plbX] = storeLB;
			storeLB = board[lbY][lbX];
			board[lbY][lbX] = 'L';
			if(cycles > 4)
			{
				prbX = rbX;
				prbY = rbY;
				rb.calcCoords(board, rbY, rbX);
				System.out.println("RB moving " + rb.retDir());
				rbY = rb.retPY();
				rbX = rb.retPX();
				if(cycles > 5)
					board[prbY][prbX] = storeRB;
				storeRB = board[rbY][rbX];
				board[rbY][rbX] = 'R';
			}
			if(cycles > 9)
			{
				pabX = abX;
				pabY = abY;
				ab.calcCoords(board, abY, abX);
				System.out.println("AB moving " + ab.retDir());
				abY = ab.retPY();
				abX = ab.retPX();
				if(cycles > 10)
					board[pabY][pabX] = storeRB;
				storeAB = board[abY][abX];
				board[abY][abX] = 'A';
			}
			if(cycles > 14)
			{
				psbX = sbX;
				psbY = sbY;
				sb.calcCoords(board, sbY, sbX, pY, pX);
				System.out.println("SB moving " + sb.retDir());
				sbY = sb.retPY();
				sbX = sb.retPX();
				if(cycles > 15)
					board[psbY][psbX] = storeSB;
				storeSB = board[sbY][sbX];
				board[sbY][sbX] = 'S';
			}
			if((lbX == pX && lbY == pY) || (plbX == pX && plbY == pY))
				System.out.println("CAUGHT");
			if((rbX == pX && rbY == pY) || (prbX == pX && prbY == pY))
				System.out.println("CAUGHT");
			if((abX == pX && abY == pY) || (pabX == pX && pabY == pY))
				System.out.println("CAUGHT");
			if((sbX == pX && sbY == pY) || (psbX == pX && psbY == pY))
				System.out.println("CAUGHT");
			for(int i = 0; i < board.length; i++)
				for(int j = 0; j < board[0].length; j++)
					if(board[i][j] != '2')
						victory = true;
					else
					{
						victory = false;
						break;
					}
			cycles++;
		}

	}
}