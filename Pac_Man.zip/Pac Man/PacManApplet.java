import java.applet.*;
import java.awt.*;

public class PacManApplet extends Applet
{
   public void paint (Graphics g)
   {
      for(int i = 0; i < 5; i++)
      	for(int j = 0; j < 5; j++)
      	{
      		g.drawRect(i * 50, j * 50, (i+1) * 50, (j+1) * 50);
		}
   }
}