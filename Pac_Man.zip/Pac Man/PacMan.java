public class PacMan
{
	char dir;
	char[][] board = new char[21][19];
	int pX;
	int pY;
	public PacMan(char d, char[][] b, int x, int y)
	{
		dir = d;
		pX = x;
		pY = y;
		for(int i = 0; i < b.length; i++)
		{
			for(int j = 0; j < b[0].length; j++)
			{
				if(b[i][j] == 1)
					board[i][j] = '2';
				else
					board[i][j] = b[i][j];
			}
		}
		calcMove();
	}
	public String toString()
	{
		String result = "";
		for(int i = 0; i < board.length; i++)
		{
			for(int j = 0; board[0].length < 7; j++)
			{
				result += board[i][j] + "\t";
			}
			result += "\n";
		}
		return result;
	}
	public void calcMove()
	{
		if(dir == 'w')
		{
			if(board[pY-1][pX] != '0')
			{
				board[pY][pX] = '1';
				pY--;
				board[pY][pX] = 'p';
			}
		}
		else if(dir == 'a')
		{
			if(pX == 0 && pY == 9)
			{
				board[pY][pX] = '1';
				pX = 18;
				board[pY][pX] = 'p';
			}
			else if(board[pY][pX-1] != '0')
			{
				board[pY][pX] = '1';
				pX--;
				board[pY][pX] = 'p';
			}
		}
		else if(dir == 'd')
		{
			if(pX == 18 && pY == 9)
			{
				board[pY][pX] = '1';
				pX = 0;
				board[pY][pX] = 'p';
			}
			else if(board[pY][pX+1] != '0')
			{
				board[pY][pX] = '1';
				pX++;
				board[pY][pX] = 'p';
			}
		}
		else if(dir == 's')
		{
			if(board[pY+1][pX] != '0')
				{
					board[pY][pX] = '1';
					pY++;
					board[pY][pX] = 'p';
				}
		}
	}
	public char[][] retBoard()
	{
		return board;
	}
	public int retPX()
	{
		return pX;
	}
	public int retPY()
	{
		return pY;
	}
}