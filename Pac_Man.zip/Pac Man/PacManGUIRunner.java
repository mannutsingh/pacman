import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class PacManGUIRunner extends JFrame
{
	boolean victory = false;
	int cycles = 0;
	char dir;
	int pX = 9, pY = 15;
	int lbX = 9, lbY = 8;
	int rbX = 9, rbY = 9;
	int abX = 9, abY = 9;
	int sbX = 9, sbY = 9;
	int plbX = 0, plbY = 0, prbX = 0, prbY = 0,pabX = 0, pabY = 0, psbX = 0, psbY = 0;
	char storeLB = '?';
	char storeRB = '?';
	char storeAB = '?';
	char storeSB = '?';
	LeftyBoy lb = new LeftyBoy();
	RightyBoy rb = new RightyBoy();
	RandomBoy ab = new RandomBoy();
	SearchBoy sb = new SearchBoy();
	PacMan p;
	TimerListener listener;
	Timer tmr;
	KeyboardHandler handler;
	private JLabel[][] board;
		char[][] charBoard = new char[][]
		{
	      {'0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0'},
	      {'0', '2', '2', '2', '2', '2', '2', '2', '2', '0', '2', '2', '2', '2', '2', '2', '2', '2', '0'},
	      {'0', '2', '0', '0', '2', '0', '0', '0', '2', '0', '2', '0', '0', '0', '2', '0', '0', '2', '0'},
	      {'0', '2', '2', '2', '2', '2', '2', '2', '2', '2', '2', '2', '2', '2', '2', '2', '2', '2', '0'},
	      {'0', '2', '0', '0', '2', '0', '2', '0', '0', '0', '0', '0', '2', '0', '2', '0', '0', '2', '0'},
	      {'0', '2', '2', '2', '2', '0', '2', '2', '2', '0', '2', '2', '2', '0', '2', '2', '2', '2', '0'},
	      {'0', '0', '0', '0', '2', '0', '0', '0', '2', '0', '2', '0', '0', '0', '2', '0', '0', '0', '0'},
	      {'0', '0', '0', '0', '2', '0', '2', '2', '2', '2', '2', '2', '2', '0', '2', '0', '0', '0', '0'},
	      {'0', '0', '0', '0', '2', '0', '2', '0', '0', '3', '0', '0', '2', '0', '2', '0', '0', '0', '0'},
	      {'2', '2', '2', '2', '2', '2', '2', '0', '3', '3', '3', '0', '2', '2', '2', '2', '2', '2', '2'},
	      {'0', '0', '0', '0', '2', '0', '2', '0', '0', '0', '0', '0', '2', '0', '2', '0', '0', '0', '0'},
	      {'0', '0', '0', '0', '2', '0', '2', '2', '2', '2', '2', '2', '2', '0', '2', '0', '0', '0', '0'},//directly below ghost storage
	      {'0', '0', '0', '0', '2', '0', '2', '0', '0', '0', '0', '0', '2', '0', '2', '0', '0', '0', '0'},
	      {'0', '2', '2', '2', '2', '2', '2', '2', '2', '0', '2', '2', '2', '2', '2', '2', '2', '2', '0'},
	      {'0', '2', '0', '0', '2', '0', '0', '0', '2', '0', '2', '0', '0', '0', '2', '0', '0', '2', '0'},
	      {'0', '2', '2', '0', '2', '2', '2', '2', '2', 'p', '2', '2', '2', '2', '2', '0', '2', '2', '0'},
	      {'0', '0', '2', '0', '2', '0', '2', '0', '0', '0', '0', '0', '2', '0', '2', '0', '2', '0', '0'},//directly below player
	      {'0', '2', '2', '2', '2', '0', '2', '2', '2', '0', '2', '2', '2', '0', '2', '2', '2', '2', '0'},
	      {'0', '2', '0', '0', '0', '0', '0', '0', '2', '0', '2', '0', '0', '0', '0', '0', '0', '2', '0'},
	      {'0', '2', '2', '2', '2', '2', '2', '2', '2', '0', '2', '2', '2', '2', '2', '2', '2', '2', '0'},
	      {'0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0'}
		};
	private ImageIcon icoWall, icoPip, icoPipless, icoGhost, icoPac;
	private class KeyboardHandler implements KeyListener
	{
		public void keyPressed(KeyEvent event)
		{
			int asciiValue = event.getKeyCode();
			dir = event.getKeyChar();
		}

		public void keyTyped(KeyEvent event)
		{
		}

		public void keyReleased(KeyEvent event)
		{
		}
	}
	public PacManGUIRunner()
	{
		super("PacMan");
		board = new JLabel[21][19];
		icoGhost = new ImageIcon("Ghost.png");
		icoWall = new ImageIcon("Wall.png");
		icoPac = new ImageIcon("PacMan.png");
		icoPip = new ImageIcon("Pip.png");
		icoPipless = new ImageIcon("Pipless.png");
		Container cp = getContentPane();
		cp.setLayout(new GridLayout(21, 19));
		cp.setBackground(Color.BLACK);
		for(int i = 0; i < board.length; i++)
			for(int j = 0; j < 19; j++)
				{
					board[i][j] = new JLabel();
					//setIcon(i, j);
					cp.add(board[i][j]);
				}
		handler = new KeyboardHandler();

		this.addKeyListener(handler);

		listener = new TimerListener();
		tmr = new Timer(250, listener);
		tmr.start();

		setSize(800, 800);
		setVisible(true);
	}
	public void setIcon(int i, int j)
	{
		board[i][j].setText("" + charBoard[i][j]);
	}
	public void setIcon()
	{
		for(int i = 0; i < board.length; i++)
			for(int j = 0; j < board[0].length; j++)
				//board[i][j].setText("" + charBoard[i][j]);
				if(charBoard[i][j] == 'p')
					board[i][j].setIcon(icoPac);
				else if(charBoard[i][j] == '2')
					board[i][j].setIcon(icoPip);
				else if(charBoard[i][j] == '1')
					board[i][j].setIcon(icoPipless);
				else if(charBoard[i][j] == '0'||charBoard[i][j] == '3')
					board[i][j].setIcon(icoWall);
				else
					board[i][j].setIcon(icoGhost);
	}
	public static void main(String[] args)
	{
		PacManGUIRunner myApp = new PacManGUIRunner();
	}
	private class TimerListener implements ActionListener
	{
		public void actionPerformed(ActionEvent event)
		{
			p = new PacMan(dir, charBoard, pX, pY);
			pX = p.retPX();
			pY = p.retPY();
			charBoard = p.retBoard();
			plbX = lbX;
			plbY = lbY;
			lb.calcCoords(charBoard, lbY, lbX);
			//System.out.println("LB moving " + lb.retDir());
			lbY = lb.retPY();
			lbX = lb.retPX();
			if(cycles > 0)
					charBoard[plbY][plbX] = storeLB;
			storeLB = charBoard[lbY][lbX];
			charBoard[lbY][lbX] = 'L';
			if(cycles > 4)
			{
				prbX = rbX;
				prbY = rbY;
				rb.calcCoords(charBoard, rbY, rbX);
				//System.out.println("RB moving " + rb.retDir());
				rbY = rb.retPY();
				rbX = rb.retPX();
				if(cycles > 5)
					charBoard[prbY][prbX] = storeRB;
				storeRB = charBoard[rbY][rbX];
				charBoard[rbY][rbX] = 'R';
			}
			if(cycles > 9)
			{
				pabX = abX;
				pabY = abY;
				ab.calcCoords(charBoard, abY, abX);
				//System.out.println("AB moving " + ab.retDir());
				abY = ab.retPY();
				abX = ab.retPX();
				if(cycles > 10)
						charBoard[pabY][pabX] = storeAB;
				storeAB = charBoard[abY][abX];
				charBoard[abY][abX] = 'A';
			}
			if(cycles > 14)
			{
				psbX = sbX;
				psbY = sbY;
				sb.calcCoords(charBoard, sbY, sbX, pY, pX);
				//System.out.println("SB moving " + sb.retDir());
				sbY = sb.retPY();
				sbX = sb.retPX();
				if(cycles > 15)
						charBoard[psbY][psbX] = storeSB;
				storeSB = charBoard[sbY][sbX];
				charBoard[sbY][sbX] = 'S';
			}
			for(int i = 0; i < charBoard.length; i++)
				for(int j = 0; j < charBoard[0].length; j++)
					if(i != lbY && j != lbX && charBoard[i][j] == 'L')
						charBoard[i][j] = '2';
					else if(i != rbY && j != rbX && charBoard[i][j] == 'R')
						charBoard[i][j] = '2';
					else if(i != abY && j != abX && charBoard[i][j] == 'A')
						charBoard[i][j] = '2';
					else if(i != sbY && j != sbX && charBoard[i][j] == 'S')
						charBoard[i][j] = '2';
			if((lbX == pX && lbY == pY) || (plbX == pX && plbY == pY))
				System.out.println("CAUGHT");
			if((rbX == pX && rbY == pY) || (prbX == pX && prbY == pY))
				System.out.println("CAUGHT");
			if((abX == pX && abY == pY) || (pabX == pX && pabY == pY))
				System.out.println("CAUGHT");
			if((sbX == pX && sbY == pY) || (psbX == pX && psbY == pY))
				System.out.println("CAUGHT");
			for(int i = 0; i < charBoard.length; i++)
				for(int j = 0; j < charBoard[0].length; j++)
					if(charBoard[i][j] != '2')
						victory = true;
					else
					{
						victory = false;
						break;
					}
			setIcon();
			cycles++;
		}
	}
}