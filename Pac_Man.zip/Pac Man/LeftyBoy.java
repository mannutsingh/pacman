public class LeftyBoy
{
	String direction;
	int pY, pX;
	public LeftyBoy()
	{
		direction = "up";
	}
	public void directionChange(char[][] b, int lbY, int lbX)
	{
		pY = lbY;
		pX = lbX;
		if(direction.equals("up"))
		{
			if(b[pY-1][pX] == '0')
			{
				if(b[pY][pX-1] == '0')
					direction = "right";
				else
					direction = "left";
			}
		}
		if(direction.equals("left"))
		{
			if(b[pY][pX-1] == '0')
			{
				if(b[pY+1][pX] == '0')
					direction = "up";
				else
					direction = "down";
			}
		}
		if(direction.equals("right"))
		{
			if(b[pY][pX+1] == '0')
			{
				if(b[pY-1][pX] == '0')
					direction = "down";
				else
					direction = "up";
			}
		}
		if(direction.equals("down"))
		{
			if(b[pY+1][pX] == '0')
				{
					if(b[pY][pX+1] == '0')
						direction = "left";
					else
						direction = "right";
				}
		}
	}
	public void calcCoords(char[][] b, int lbY, int lbX)
	{
		directionChange(b, lbY, lbX);
		if(direction.equals("up"))
		{
			pY--;
		}
		else if(direction.equals("left"))
		{
			pX--;
		}
		else if(direction.equals("right"))
		{
			pX++;
		}
		else
		{
			pY++;
		}
	}
	public int retPX()
	{
		return pX;
	}
	public int retPY()
	{
		return pY;
	}
	public String retDir()
	{
		return direction;
	}
}