import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class InterfaceRun extends JFrame
{
	private ImageIcon icoBackground;
	private JLabel lblBackground;
	public InterfaceRun()
	{
		super("Pac-Man");
		Container cp = getContentPane();

		cp.setLayout(new GridLayout(10, 10));

		icoBackground = new ImageIcon("Image.jpg");

		cp.setIcon(icoBackground);
	}
}
